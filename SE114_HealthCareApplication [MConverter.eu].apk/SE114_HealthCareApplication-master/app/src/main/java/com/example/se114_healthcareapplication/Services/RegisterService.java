package com.example.se114_healthcareapplication.Services;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.IBinder;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.example.se114_healthcareapplication.Recievers.AlarmReciever;

public class RegisterService extends Service {
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

    }

    @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        registerReceiver(new AlarmReciever(),new IntentFilter("CUSTOM_ALARM"), Context.RECEIVER_NOT_EXPORTED);
        return START_STICKY;
    }
}
