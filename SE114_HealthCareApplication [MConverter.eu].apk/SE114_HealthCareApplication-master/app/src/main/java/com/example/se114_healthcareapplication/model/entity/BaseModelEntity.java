package com.example.se114_healthcareapplication.model.entity;

public class BaseModelEntity {
}
