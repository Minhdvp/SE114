package com.example.se114_healthcareapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class test_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
    }
}